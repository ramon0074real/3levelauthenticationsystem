import cv2
import numpy as np
from skimage.morphology import skeletonize, thin
from skimage.color import rgb2gray
import matplotlib.pyplot as plt
from scipy import ndimage
from sklearn.cluster import KMeans
import face_recognition

import sys
from enhance import image_enhance
from tkinter import *
import tkinter.messagebox

# ======================================
# FACE RECOGNITION
# ======================================

#global Var
is_face_rec = False
is_finger_rec = False
is_seg_completed = False

video_capture = cv2.VideoCapture(0, cv2.CAP_DSHOW)

# Load a sample picture and learn how to recognize it.
db_image = face_recognition.load_image_file("facerecdb/fr_keji.jpg")
db_image_encoding = face_recognition.face_encodings(db_image)[0]


# Create arrays of known face encodings and their names
known_face_encodings = [
    db_image_encoding,
]
known_face_names = [
    "Authorized User",
]

# Initialize some variables
face_locations = []
face_encodings = []
face_names = []
process_this_frame = True
found = False

while True:
    # Grab a single frame of video
    ret, frame = video_capture.read()

    # Resize frame of video to 1/4 size for faster face recognition processing
    small_frame = cv2.resize(frame, (0, 0), fx=0.25, fy=0.25)

    # Convert the image from BGR color (which OpenCV uses) to RGB color (which face_recognition uses)
    rgb_small_frame = small_frame[:, :, ::-1]

    # Only process every other frame of video to save time
    if process_this_frame:
        # Find all the faces and face encodings in the current frame of video
        face_locations = face_recognition.face_locations(rgb_small_frame)
        face_encodings = face_recognition.face_encodings(rgb_small_frame, face_locations)

        face_names = []
        for face_encoding in face_encodings:
            # See if the face is a match for the known face(s)
            matches = face_recognition.compare_faces(known_face_encodings, face_encoding)
            name = "Unknown"

            # # If a match was found in known_face_encodings, just use the first one.
            # if True in matches:
            #     first_match_index = matches.index(True)
            #     name = known_face_names[first_match_index]

            # Or instead, use the known face with the smallest distance to the new face
            face_distances = face_recognition.face_distance(known_face_encodings, face_encoding)
            best_match_index = np.argmin(face_distances)
            if matches[best_match_index]:
                name = known_face_names[best_match_index]

            face_names.append(name)

    process_this_frame = not process_this_frame


    # Display the results
    for (top, right, bottom, left), name in zip(face_locations, face_names):
        # Scale back up face locations since the frame we detected in was scaled to 1/4 size
        top *= 4
        right *= 4
        bottom *= 4
        left *= 4

        # Draw a box around the face
        cv2.rectangle(frame, (left, top), (right, bottom), (0, 0, 255), 2)

        # Draw a label with a name below the face
        cv2.rectangle(frame, (left, bottom - 35), (right, bottom), (0, 0, 255), cv2.FILLED)
        font = cv2.FONT_HERSHEY_DUPLEX
        cv2.putText(frame, name, (left + 6, bottom - 6), font, 1.0, (255, 255, 255), 1)

    if(found==True):
        break
    # Display the resulting image
    cv2.imshow('Authorized User', frame)

    # Hit 'q' on the keyboard to quit!
    if cv2.waitKey(1) & 0xFF == ord('q'):
        break

# Release handle to the webcam
video_capture.release()
cv2.destroyAllWindows()

#if face is recognized, display message. Else, display message and quit
if('Authorized User' in face_names):
    found = True
    print(name, "found")
    tkinter.messagebox.showinfo('Authorized','Authorized access. Face Matched. Please wait for image segmentation.')
    is_face_rec = True
else:
    print("User Not Authorized.")
    tkinter.messagebox.showinfo('UnAuthorized','UnAuthorized access. Face doesn''t match. Application exiting.')
    exit()

# ======================================
# IMAGE SEGMENTATION 
# ======================================

#encoding=utf-8
import pygame, sys, random
from pygame.locals import *

#reload(sys)
#sys.setdefaultencoding('utf8')

# some constants
WINDOWWIDTH = 500
WINDOWHEIGHT = 500
BACKGROUNDCOLOR = (255, 255, 255)
BLUE = (0, 0, 255)
BLACK = (0, 0, 0)
FPS = 40

VHNUMS = 3
CELLNUMS = VHNUMS * VHNUMS
MAXRANDTIME = 100


# quit
def terminate():
    pygame.quit()
    sys.exit()


# Randomly generate the game board
def newGameBoard():
    board = []
    for i in range(CELLNUMS):
        board.append(i)
    blackCell = CELLNUMS - 1
    board[blackCell] = -1

    for i in range(MAXRANDTIME):
        direction = random.randint(0, 3)
        if (direction == 0):
            blackCell = moveLeft(board, blackCell)
        elif (direction == 1):
            blackCell = moveRight(board, blackCell)
        elif (direction == 2):
            blackCell = moveUp(board, blackCell)
        elif (direction == 3):
            blackCell = moveDown(board, blackCell)
    return board, blackCell


# If the blank image block is not at the far left, move the block to the left of the blank block to the blank block position
def moveRight(board, blackCell):
    if blackCell % VHNUMS == 0:
        return blackCell
    board[blackCell - 1], board[blackCell] = board[blackCell], board[blackCell - 1]
    return blackCell - 1


# If the blank image block is not on the far right, move the block to the right of the blank block to the blank block position
def moveLeft(board, blackCell):
    if blackCell % VHNUMS == VHNUMS - 1:
        return blackCell
    board[blackCell + 1], board[blackCell] = board[blackCell], board[blackCell + 1]
    return blackCell + 1


# If the blank image block is not at the top, move the block above the blank block to the blank block position
def moveDown(board, blackCell):
    if blackCell < VHNUMS:
        return blackCell
    board[blackCell - VHNUMS], board[blackCell] = board[blackCell], board[blackCell - VHNUMS]
    return blackCell - VHNUMS


# If the blank image block is not at the bottom, move the block below the blank block to the blank block position
def moveUp(board, blackCell):
    if blackCell >= CELLNUMS - VHNUMS:
        return blackCell
    board[blackCell + VHNUMS], board[blackCell] = board[blackCell], board[blackCell + VHNUMS]
    return blackCell + VHNUMS


# Is it done
def isFinished(board, blackCell):
    for i in range(CELLNUMS - 1):
        if board[i] != i:
            return False
    return True


# initialize
pygame.init()
mainClock = pygame.time.Clock()

# load image
gameImage = pygame.image.load('segdb/pic.png')
gameRect = gameImage.get_rect()

# setup window
windowSurface = pygame.display.set_mode((gameRect.width, gameRect.height))
#pygame.display.set_caption('拼图'.decode('utf-8').encode('gb2312'))

cellWidth = int(gameRect.width / VHNUMS)
cellHeight = int(gameRect.height / VHNUMS)

finish = False

gameBoard, blackCell = newGameBoard()

# main segmentation loop
while not finish:
    for event in pygame.event.get():
        if event.type == QUIT:
            tkinter.messagebox.showinfo('UnAuthorized','UnAuthorized access. Image segmentation not completed. Application exiting.')
            print("Unauthorized access. Terminated by user. Image segmentation not done.")
            terminate()
        if finish:
            # continue
            print("finish")
        if event.type == KEYDOWN:
            if event.key == K_LEFT or event.key == ord('a'):
                blackCell = moveLeft(gameBoard, blackCell)
            if event.key == K_RIGHT or event.key == ord('d'):
                blackCell = moveRight(gameBoard, blackCell)
            if event.key == K_UP or event.key == ord('w'):
                blackCell = moveUp(gameBoard, blackCell)
            if event.key == K_DOWN or event.key == ord('s'):
                blackCell = moveDown(gameBoard, blackCell)
        if event.type == MOUSEBUTTONDOWN and event.button == 1:
            x, y = pygame.mouse.get_pos()
            col = int(x / cellWidth)
            row = int(y / cellHeight)
            index = col + row * VHNUMS
            if (index == blackCell - 1 or index == blackCell + 1 or index == blackCell - VHNUMS or index == blackCell + VHNUMS):
                gameBoard[blackCell], gameBoard[index] = gameBoard[index], gameBoard[blackCell]
                blackCell = index

    if (isFinished(gameBoard, blackCell)):
        gameBoard[blackCell] = CELLNUMS - 1
        finish = True

    windowSurface.fill(BACKGROUNDCOLOR)

    for i in range(CELLNUMS):
        rowDst = int(i / VHNUMS)
        colDst = int(i % VHNUMS)
        rectDst = pygame.Rect(colDst * cellWidth, rowDst * cellHeight, cellWidth, cellHeight)

        if gameBoard[i] == -1:
            continue

        rowArea = int(gameBoard[i] / VHNUMS)
        colArea = int(gameBoard[i] % VHNUMS)
        rectArea = pygame.Rect(colArea * cellWidth, rowArea * cellHeight, cellWidth, cellHeight)
        windowSurface.blit(gameImage, rectDst, rectArea)

    for i in range(VHNUMS + 1):
        pygame.draw.line(windowSurface, BLACK, (i * cellWidth, 0), (i * cellWidth, gameRect.height))
    for i in range(VHNUMS + 1):
        pygame.draw.line(windowSurface, BLACK, (0, i * cellHeight), (gameRect.width, i * cellHeight))

    pygame.display.update()
    mainClock.tick(FPS)

if(finish):
    is_seg_completed = True
    print("Authorized access. Image segmentation completed.")
    tkinter.messagebox.showinfo('Authorized','Authorized access. Image segmentation completed. Please wait for finger print authentication.')
    pygame.quit()
else:
    tkinter.messagebox.showinfo('UnAuthorized','UnAuthorized access. Image segmentation not completed. Application exiting.')
    # pygame.quit()
    terminate()


# ======================================
# FINGERPRINT RECOGNITION
# ======================================

def removedot(invertThin):
    temp0 = np.array(invertThin[:])
    temp0 = np.array(temp0)
    temp1 = temp0/255
    temp2 = np.array(temp1)
    temp3 = np.array(temp2)

    enhanced_img = np.array(temp0)
    filter0 = np.zeros((10,10))
    W,H = temp0.shape[:2]
    filtersize = 6

    for i in range(W - filtersize):
        for j in range(H - filtersize):
            filter0 = temp1[i:i + filtersize,j:j + filtersize]

            flag = 0
            if sum(filter0[:,0]) == 0:
                flag +=1
            if sum(filter0[:,filtersize - 1]) == 0:
                flag +=1
            if sum(filter0[0,:]) == 0:
                flag +=1
            if sum(filter0[filtersize - 1,:]) == 0:
                flag +=1
            if flag > 3:
                temp2[i:i + filtersize, j:j + filtersize] = np.zeros((filtersize, filtersize))

    return temp2

def get_descriptors(img):
	clahe = cv2.createCLAHE(clipLimit=2.0, tileGridSize=(8,8))
	img = clahe.apply(img)
	img = image_enhance.image_enhance(img)
	img = np.array(img, dtype=np.uint8)

	# Threshold
	ret, img = cv2.threshold(img, 127, 255, cv2.THRESH_BINARY_INV | cv2.THRESH_OTSU)

	# Normalize to 0 and 1 range
	img[img == 255] = 1

	#Thinning
	skeleton = skeletonize(img)
	skeleton = np.array(skeleton, dtype=np.uint8)
	skeleton = removedot(skeleton)

	# Harris corners
	harris_corners = cv2.cornerHarris(img, 3, 3, 0.04)
	harris_normalized = cv2.normalize(harris_corners, 0, 255, norm_type=cv2.NORM_MINMAX, dtype=cv2.CV_32FC1)
	threshold_harris = 125

	# Extract keypoints
	keypoints = []
	for x in range(0, harris_normalized.shape[0]):
		for y in range(0, harris_normalized.shape[1]):
			if harris_normalized[x][y] > threshold_harris:
				keypoints.append(cv2.KeyPoint(y, x, 1))

	# Define descriptor
	orb = cv2.ORB_create()

	# Compute descriptors
	_, des = orb.compute(img, keypoints)
	return (keypoints, des)

path1 = r'fingerdb/101_1.tif'
img1 = cv2.imread(path1, cv2.IMREAD_GRAYSCALE)
kp1, des1 = get_descriptors(img1)

path2 = r'fingerdb/101_2.tif'
img2 = cv2.imread(path2, cv2.IMREAD_GRAYSCALE)
kp2, des2 = get_descriptors(img2)

# Matching between descriptors
bf = cv2.BFMatcher(cv2.NORM_HAMMING, crossCheck=True)
matches = sorted(bf.match(des1, des2), key= lambda match:match.distance)

# Plot keypoints
img4 = cv2.drawKeypoints(img1, kp1, outImage=None)
img5 = cv2.drawKeypoints(img2, kp2, outImage=None)
f, axarr = plt.subplots(1,2)
axarr[0].imshow(img4)
axarr[1].imshow(img5)
plt.show()

# Plot matches
img3 = cv2.drawMatches(img1, kp1, img2, kp2, matches, flags=2, outImg=None)
plt.imshow(img3)
plt.show()

# Calculate score
score = 0
for match in matches:
    score += match.distance
score_threshold = 33

#if matches
if score/len(matches) < score_threshold:
    print("Fingerprint matches.")
    tkinter.messagebox.showinfo("Authorized","Fingerprint Matched.")
    is_finger_rec = True

else: #else if doesnt match
    print("Fingerprint does not match.")
    tkinter.messagebox.showinfo('Authorized','Fingerprint doesn''t match. Application exiting.')
    exit()

#If all true show login dashboard
if is_face_rec==True & is_finger_rec==TRUE & is_seg_completed == True:
    print("User Logged In Successfully")
    gui = Tk()
    gui.geometry("500x500")
    text = Label(gui, text="User Authenticated", fg="Green", font=("Helvetica", 18)).place(relx=.5, rely=.5, anchor="center")
    gui.mainloop()
    exit()

sys.exit()
